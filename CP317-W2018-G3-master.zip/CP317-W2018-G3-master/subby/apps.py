from django.apps import AppConfig

class SubbyAppConfig(AppConfig):
    name = 'subby'
